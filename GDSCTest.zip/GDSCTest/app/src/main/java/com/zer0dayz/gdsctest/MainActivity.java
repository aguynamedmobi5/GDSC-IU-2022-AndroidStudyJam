package com.zer0dayz.gdsctest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    private Button button;
    private EditText nameText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.button);
        nameText = findViewById(R.id.nameText);



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this, TestActivity.class);
                String name = nameText.getText().toString();
                intent.putExtra("EXTRA_STRING", name);
                startActivity(intent);
                // Toast.makeText(MainActivity.this, "Downloading File", Toast.LENGTH_LONG).show();

//                Snackbar.make(button, "Hello "+ name, Snackbar.LENGTH_LONG)
//                        .setAction("Cancel", new View.OnClickListener() {
//                            @Override
//                            public void onClick(View view) {
//
//                            }
//                        })
//                        .show();
            }
        });



    }


}